repo: Ddreamnet/nebula-genc-zeka
branch: main
path: web/src

## Last sync

date: 2026-09-06T18:43:08Z

### Updated in this project

- Öğretmen paneli üç navigasyon yönünde yeniden tasarlandı: ikon şeridi (1a), yüzen üst bar (1b), sağdan yan panel (1c).
- Panelin şekil dili yumuşatıldı — kaynaktaki 3px lacivert kontur + sert ofset gölge yerine 1px ince kontur + katmanlı yumuşak gölge; pastel dolgu yerine krem kart + renkli şerit.
- Öğrenci listesi sıkı satırlara çekildi (20 öğrenci hedefi) ve sonraki derse göre sıralanıyor; derste olan öğrenci nabız atan noktayla işaretli.
- Kaynaktaki emoji (selamlamadaki 👋) kaldırıldı — CLAUDE.md emoji kullanmıyor.
- Marka işareti gerçek varlıklarla: dairesel `nebula-square.png` şeritte, `logo-black.png` lockup 1b'nin krem barında.
- Şerit ikonları `lucide-react` set'inin (LogOut, BookOpen, Wallet, Calendar, FileUser, Sparkles) gerçek path verisiyle çizildi; kalem kalınlığı bilinçli olarak 1.7 (lucide varsayılanı 2).
- Panel v2: krem + açık mavi iki katman olarak (zemin `--tint-blue`, kartlar krem, şerit `--space-blue`); sıradaki ders şeridi, satırlarda okunmamış ödev sayısı, dakika bakiyesi, haftalık yük grafiği.
- "Ders işlendi" tek butonu **ders zinciriyle** değiştirildi. `lesson_instances` şemasında her 40 dk ayrı bir satır (kendi `lesson_number`, tarih, saat, planned/completed) — tek buton hangi dersi tamamladığını söyleyemiyordu. Artık her ders kendi satırı, aynı günün iki dersi kartlar arasındaki yarım halkalarla bağlı.
- Erteleme birinci sınıf eylem oldu (`rescheduled_count` / `original_date` şemada var): her ders satırının sağında takvim ikonu. Ayrılan çift, zincir kopuk + mercan renkte çiziliyor.
- Geri alma: işaretli derse tekrar dokunma (`rpc_undo_complete_lesson`).
- Mobil 4a/4b/4c: 4 öğrenci + "Tümünü gör", seçim yokken kesikli boş alan, seçince ders zinciri + konular, ödev karti alttan (sekme yok).

## Screen map

| Proje ekranı | Kaynak dosyalar |
|---|---|
| Nebula Ana Sayfa.dc.html | web/src/app/(marketing)/page.tsx · web/src/app/(marketing)/layout.tsx · web/src/app/(marketing)/landing.css · web/src/app/layout.tsx |
| — Header | web/src/components/landing/landing-navbar.tsx · web/src/lib/site.ts |
| — Hero | web/src/components/landing/hero.tsx · web/src/components/landing/contact-ctas.tsx · web/src/components/ui/paper-button.tsx · web/src/components/ui/brand-icons.tsx |
| — 01 Ne üretiyor | web/src/components/landing/curriculum.tsx · web/src/components/landing/output-art.tsx · web/src/lib/outputs.ts |
| — 02 Nasıl işliyor | web/src/components/landing/how-it-works.tsx |
| — 03 Site içi AI | web/src/components/landing/playground-teaser.tsx · web/src/components/playground/provider-logos.tsx |
| — 04 Bülten | (kaynakta yok; `ref/bulten-tasarim-brief.md` + Bülten H01–H04 PDF'lerinden) |
| — 05 Güven | web/src/components/landing/safety.tsx · web/src/components/landing/faq.tsx |
| Nebula Mobil Hero.dc.html | web/src/components/landing/landing-navbar.tsx · web/src/components/landing/hero.tsx |
| — 06 İletişim | web/src/components/landing/closing-cta.tsx |
| — Nova & sahne parçaları | web/src/components/cast/nova.tsx · web/src/components/cast/props.tsx · web/src/components/cast/nova-blink.tsx |
| — Tokenlar & tipografi | web/src/lib/landing-theme.ts · web/src/lib/landing-fonts.ts · brand-kit/BRAND.md |
| Nebula Öğretmen Paneli.dc.html | web/src/components/dashboard/teacher-dashboard.tsx · web/src/app/dashboard/page.tsx · web/src/app/dashboard/layout.tsx |
| — Ders tamamlama & erteleme | web/src/lib/lesson/types.ts · web/src/lib/lesson/service.ts (rpc_complete_lesson, rpc_undo_complete_lesson, getRemainingRights) |
| — Panel bileşen dili | web/src/components/panel-ui/button.tsx · web/src/components/panel-ui/card.tsx · web/src/components/dashboard/welcome-banner.tsx |
| — Panel teması & token'lar | web/src/app/globals.css (`.panel-theme`, `.pn-btn`, `.pn-card`, `.panel-grid-bg`) |
| — Marka kilidi | web/src/components/site/logo.tsx · web/public/brand/nebula-square.png |
| Nebula Öğretmen Paneli v2.dc.html | (1a–1c'nin gelişmiş hâli) + web/src/components/dashboard/homework-list-dialog.tsx · upload-homework-dialog.tsx · homework-notification-bell.tsx |

## Sync history

### 2026-09-05 — Ana sayfa & mobil hero

date: 2026-09-05T00:05:00Z

### Updated in this project

- Mobil hero (390×844) kaynaktaki mobil desenlerden çıkarıldı: nav `md` altında gizli, ikon "Giriş yap" + hamburger.
- Yeni hero (dalgalı egzoz, uzay mekiği, gezegenler) tek kolona yeniden çözüldü; alan yandaki sütun yerine üstte bant.
- Bülten bölümü (04) eklendi, sonraki bölümler 05/06 olarak numaralandı.
- Bölüm zeminleri üç stile bölündü; pastel dörtlü `CLAUDE.md`'ye temel palet olarak yazıldı.

