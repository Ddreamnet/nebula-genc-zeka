# Nebula paneli: 5a tasarım sistemi

Bu belge **5a** tasarımının (Öğretmen Paneli v2, `id="5a"`) bütün panellere uygulanması için gereken kuralları topluyor: **öğretmen, öğrenci, yönetici, playground**. Kaynak dosya `panel-varyasyonlari.dc.html`. Onaylı bölümler **5a** (masaüstü) ile **4a/4b/4c** (mobil). Diğerleri karşılaştırma için dosyada duruyor.

Aşağıdaki değerlerin hepsi 5a'dan ölçülerek alındı. Bir değer yoksa, yenisini uydurmak yerine buradaki en yakın değeri kullanın.

---

## 1. Temel ilkeler

1. **Sol şerit yok.** Navigasyon, üstte yüzen tek bir lacivert bar.
2. **Butonlar adlarıyla birlikte duruyor.** Her eylem, ikon ve altında adı olan renkli bir döşeme. Masaüstünde de mobilde de yazı kalıyor.
3. **Birbirine ait olan tek kartta durur.** Örnek: öğrenci ve paketi. Aynı şeyi ikiye bölen kenarlık kullanılmaz.
4. **Pasteller tam tonda.** Yıkanmış tint'ler (#E8F4EC, #E9EFFC) yalnızca zeminde kullanılır; kart başlıklarında kullanılmaz.
5. **Kart gövdeleri kremdir.** Renk başlık bantlarında ve durum işaretlerinde durur. Panelde saatlerce çalışılıyor, gövdeler gözü yormamalı.
6. **Tür bilgisi bir kez yazılır.** Örnek: TEORİ/LAB, her kutuda tekrar edilmez, satır etiketi olarak bir kez yazılır.
7. **Durum veriden gelir.** Bir öğenin rengi `status` alanından türetilir, listedeki sırasından türetilmez.
8. **Emoji yok.** İkonlar lucide çizgi ikonları, çizgi kalınlığı 1.8–1.9.

---

## 2. Renk tokenları

### Pastel dörtlü (+ mor)
| Rol | Dolgu | Mürekkep (dolgunun üstünde, ≥4.5:1) | Vurgu / kenar |
|---|---|---|---|
| Nane | `#C6F1DC` | `#0F6B41` | `rgba(23,145,91,.45)` |
| Şeftali | `#FFE1C4` | `#9C4A0A` (buton yazısı `#3B1A05`) | `#D2701A` |
| Pembe | `#FFD6DE` | `#8C1F3B` | `rgba(178,47,79,.46)` |
| Mavi | `#CFE1FF` | `#1B2A6B` | `rgba(36,55,166,.22)` |
| Mor | `#DCD2FF` | `#2A1466` | `rgba(74,47,184,.5)` |

### Nötrler
| Kullanım | Değer |
|---|---|
| Kart gövdesi (krem) | `#FFFBF2` |
| Ana mürekkep | `#152343` |
| İkincil metin | `#2C3550` |
| Soluk metin (tarih, meta) | `#5B6480`. **`#8A93AC` metinde kullanılmaz**: bu bir kontur token'ı ve metin olarak 2.97:1 kalıyor. |
| Bar / uzay mavisi | `#1B3564` |
| Bar üstü açık metin | `#F2F6FF`, ikincil `#9DB4DE` |
| Sayfa (masa) zemini | `#E2F0E8` |
| Çalışma alanı zemini | `#E8F4EC` + nokta dokusu `radial-gradient(rgba(23,145,91,.15) 1.4px, transparent 1.4px)` / `26px 26px` |
| İnce ayırıcı | `rgba(21,35,67,.10)` – `.13` |

### Kontrast kuralı
Her metin, arkasındaki gerçek zemine karşı en az **4.5:1** olmalı (büyük başlıklarda 3:1). Yarı saydam zeminlerde oran, katmanlar birleştirildikten sonraki renkle ölçülür.

---

## 3. Tipografi

| Rol | Font | Ağırlık | Boyut | Not |
|---|---|---|---|---|
| Başlık / öğrenci adı (kart) | **Sora** | 700 | 24px (mobil 19) | `letter-spacing:-.025em`. Türkçe ğ, ı, ş net. Fredoka kullanılmaz. |
| Kart başlığı | Sora | 600 | 15px | `-.015em` |
| Gövde, liste adları | **Nunito** | 600–700 | 13–14.5px | Öğrenci listesindeki adlar Nunito kalır. |
| Etiket / tarih / sayı | **IBM Plex Mono** | 600 | 9–11px | UPPERCASE, `letter-spacing:.06–.14em` |
| Ders kutusu rakamı | Sora | 700 | 15px (5a) / 16px (mobil) | |

Google Fonts: `Sora:wght@500;600;700`, `Nunito:wght@400;600;700`, `IBM+Plex+Mono:wght@500;600`.

---

## 4. Şekil, gölge, hareket

| Öğe | Yarıçap |
|---|---|
| Çerçeve / yüzen bar | 18–20px |
| Kart | 16–20px |
| Buton / döşeme | 12–14px |
| Ders kutusu | 10px (5a) / 11px (mobil) |
| Rozet / sayaç | 999px |

**Kontur:** 1px ince (`rgba(21,35,67,.13)` ya da ilgili pastelin kenar tonu). Sitedeki 3px sticker kontur panelde **kullanılmaz**.

**Gölge:** Katmanlı ve yumuşak.
- Kart: `0 1px 2px rgba(21,35,67,.05), 0 10px 26px -18px rgba(21,35,67,.22)`
- Hover: `translateY(-1px/-2px)` ve renkli yumuşak gölge `0 6px 16px -6px <ton .34–.5>`

**Hareket:** Tüm geçişlerde `cubic-bezier(.2,.7,.3,1)` kullanılır. `prefers-reduced-motion` açıksa hepsi kapanır.

| Nerede | Ne | Süre |
|---|---|---|
| Buton / döşeme hover | translateY + gölge | .16s |
| Liste satırı hover | yalnızca background | .16s |
| Yan panel (masaüstü) | `translateX(100%) → 0`, komşu kart sıkışır | .26s |
| Alttan kart (mobil) | `translateY(100%) → 0` + perde `opacity 0→1` | .28s / .2s |
| "Şu an" nabzı | `@keyframes nbNow` / `nbNowAmber`: `box-shadow 0 0 0 0 → 0 0 0 5px` şeffaf | 2.4s sonsuz |

---

## 5. Yüzen bar (bütün paneller)

- **Konum:** çerçevenin üstünde. `left/right:20px`, `top:18px`, yükseklik **82px**, `border-radius:18px`, zemin `#1B3564`.
- **Gölge:** `0 2px 4px rgba(19,39,80,.14), 0 16px 34px -18px rgba(19,39,80,.44)`
- **Sol taraf:** beyaz logo (`logo-white.png`, 38px yükseklik), 1px ayırıcı, iki satırlık selamlama.
  - Üst satır: Sora 600 15px `#F2F6FF`, örnek "İyi dersler, Selin".
  - Alt satır: Plex Mono 9.5px `#9DB4DE`, örnek "21 EYLÜL PAZARTESİ · BUGÜN 3 DERS".
- **Sağ taraf: eylem döşemeleri.**
  - Boyut: 66px genişlik, `padding:8px 0 7px`, `border-radius:14px`, kontur yok.
  - İçerik: 22px ikon, altında Plex Mono 9px 600 UPPERCASE ad.
  - Renk: her döşeme kendi pastelinde, mürekkep aynı pastelin koyu tonu.
- **Bildirim sayacı:** döşemenin sağ üstünde. `#B22F4F` dolgu, `2px #1B3564` kenar, 17px.

Panellere göre döşemeler (sıra korunur):

| Panel | Döşemeler |
|---|---|
| Öğretmen | PROGRAM (mavi) · BAKİYE (şeftali) · STÜDYO (mor) · BİLDİRİM (nane) · ÇIKIŞ (pembe) |
| Öğrenci | DERSLER (mavi) · ÖDEVLER (şeftali) · STÜDYO (mor) · BÜLTEN (nane) · ÇIKIŞ (pembe) |
| Yönetici | ÖĞRETMENLER (mavi) · ÖĞRENCİLER (nane) · PAKETLER (şeftali) · BİLDİRİM (mor) · ÇIKIŞ (pembe) |
| Playground | GEÇMİŞ (mavi) · CEVHER bakiyesi (nane, bilgi çipi) · PANEL'E DÖN (pembe) |

Öğrenci, yönetici ve playground satırlarındaki döşeme adları öneridir. Üründeki gerçek sayfa adlarıyla eşleştirin. Pembe her zaman ÇIKIŞ ya da geri dönüştür. Döşeme sayısı 5'i geçmesin.

---

## 6. Yerleşim (masaüstü)

- **Çerçeve:** `left/right:20px`, `top:112px` (barın altı), `bottom:20px`, `display:flex; gap:14px`.
- **Sol kolon: liste kartı**, 228px sabit genişlik.
  - Başlık bandı nane `#C6F1DC`: kart başlığı, krem sayaç çipi, arama alanı.
  - Gövde gruplu liste: "BUGÜN" / "BU HAFTA" etiketleri, Plex Mono 9.5px.
- **Sağ kolon:** `flex:1`, `gap:12px`. Üstte **seçili öğe kartı** (§7), altında **içerik kartı** (§8).
- **Yan panel** (Ödevler, Bakiye):
  - İçerik kartıyla aynı flex satırının ikinci çocuğudur, overlay değildir. Böylece yükseklikleri yapısal olarak eşit kalır.
  - Açıldığında içerik kartı sıkışır; başlıklar `text-overflow:ellipsis` ile kısalır.
  - Sağdaki ikincil bilgiler (rozet, kaynak sayısı) dar genişlikte gizlenir.
  - **Ekstra sayfa açılmaz.**

### Liste satırı
- Ölçü: `padding:7–9px 9px`, `border-radius:9px`, `border-left:3px solid <durum>`.
- İçerik:
  - 7px durum noktası; "şu an" ise nabız atar.
  - Ad: Nunito 13.5–14.5px 600.
  - Okunmamış sayaç pill'i: pembe `#FFD6DE` / `#8C1F3B`, `min-width:16px`, yükseklik 16px.
  - Saat: Plex Mono 10.5px.
- Seçili satır: tint zemin ve 3px renkli sol kenar.

---

## 7. Seçili öğe kartı (5a öğrenci kartı), ana bileşen

**Tek mavi kart, tek satır.** Sağ kolonun en üstünde durur.

```
┌──────────────────────────────────────────────────────────────────────┐
│ Elif Yıldız            TEORİ [1][3][5][7]            [👤] [📄 Ödevler] │
│ Pazartesi 17:00—18:20    LAB [2][4][6][8]                              │
│                          31 AĞU 7 EYL 14 EYL 21 EYL                    │
│                                            + 28 EYL                    │
└──────────────────────────────────────────────────────────────────────┘
```

- **Kart:** `background:#CFE1FF`, `border:1px solid rgba(36,55,166,.22)`, `border-radius:20px`, `padding:14px 18px`, `display:flex; align-items:center; gap:20px`. Yükseklik yaklaşık 136px.
- **Sol:** ad (Sora 700 24px `#152343`), altında zaman aralığı (Nunito 14px `#2C3550`). `flex-shrink:0`.
- **Orta (paket ızgarası):** `flex:1`, içinde `max-width:400px` ve ortalı bir grid.
  - `grid-template-columns: auto repeat(4, minmax(0,1fr))`, `column-gap:8px`, `row-gap:5px`.
  - Satır 1: "TEORİ" etiketi (Plex Mono 10.5px 600, `#1B2A6B`, sağa hizalı) ve 1·3·5·7.
  - Satır 2: "LAB" etiketi (`#8C1F3B`) ve 2·4·6·8.
  - Satır 3: boş hücre ve her kolonun altında tarih. Ertelenmiş dersin yeni tarihi ikinci satırda pembe `+ 28 EYL` olarak yazılır.
  - **Kolon = hafta**, **dikey = aynı günün 40+40 çifti.** Çizgi ya da bağlantı kullanılmaz.
- **Ders kutusu:** yükseklik 34px, `border-radius:10px`, `border:1.5px solid <kenar>`, rakam Sora 700 15px. Hover'da `translateY(-2px)`.
- **Sağ:**
  - "Öğrenci hakkında" butonu: yalnızca ikon, 50×50, beyaz `#FFFFFF`, 1px `rgba(36,55,166,.16)` kenar, 14px yarıçap. `aria-label` zorunlu.
  - Hemen sağında **Ödevler** butonu: 50px yükseklik, şeftali `#FFE1C4`, `#3B1A05` yazı, kenar `rgba(210,112,26,.40)`, Nunito 700 15px, 18px belge ikonu.

### Ders durum tonları (`lesson_instances.status` + erteleme)
| Durum | Dolgu | Kenar | Rakam | Ek |
|---|---|---|---|---|
| İşlendi | `#C6F1DC` | `rgba(23,145,91,.45)` | `#0B4F30` | |
| Şu an | `#FFE1C4` | `#D2701A` | `#9C4A0A` | `nbNowAmber` nabzı |
| Planlı | `#FFFBF2` | `rgba(21,35,67,.22)` | `#5B6480` | |
| Ertelendi | `#FFD6DE` | `rgba(178,47,79,.46)` | `#8C1F3B` | kolon altında `+ <yeni tarih>` |

İçinde bulunulan haftanın tarihi `#9C4A0A` renkte yazılır. **Kutu, tarih ve vurgu aynı kolonda olmalı.** Bugünün dersini içeren hafta, bugünün tarihini taşır.

### Veri
- Paket **8 derstir** (4 hafta × 40+40), 16 değildir.
- Tek ders = tek `lesson_instances` satırı. Tamamla: `rpc_complete_lesson`. Geri al: aynı kutuya tekrar dokunmak (`rpc_undo_complete_lesson`).
- Kalan hak `getRemainingRights`'tan alınır. Gösterilecekse ızgarayla tutarlı olmalı (8 − işlenen).

### Diğer panellere uyarlama
| Panel | Kartın solu | Orta ızgara | Sağ butonlar |
|---|---|---|---|
| Öğretmen | Öğrenci adı + ders saati | Öğrencinin paketi | 👤 Öğrenci hakkında · Ödevler |
| Öğrenci | "Merhaba, Elif" + sıradaki ders | Kendi paketi (aynı ızgara) | 📄 Ödevler · Stüdyo |
| Yönetici | Öğretmen adı + öğrenci sayısı | Haftalık ders yükü ya da seçili öğrencinin paketi | ✎ Düzenle · Fotoğraf yükle (**profil fotoğrafını yalnızca admin yükler**) |
| Playground | Aktif model (logo + ad + sağlayıcı) | Model ayarları çipleri (en/boy `aspect.ts`, varsayılan 9:16) | Geçmiş · Cevher |

---

## 8. İçerik kartı (örnek: Konular)

- Krem gövde, 1px kontur, 16px yarıçap.
- Başlık bandı pembe `#FFD6DE`, alt kenar `rgba(178,47,79,.22)`. İçinde başlık "7. dersin konuları", ilerleme çubuğu (6px, nane dolgu) ve `2/6` sayacı.
- **Satır:** `padding:8–10px 12px`, `border-radius:12px`, 3px durum renkli sol kenar, 20px durum dairesi (tik), başlık Nunito 14px 600 ve ellipsis.
- Gövde `overflow-y:auto` olur, ama satır sayısı normalde sığacak şekilde ayarlanır. **Yarısı kesilmiş satır bırakılmaz.**

Diğer panellerde bu kartın yerine gelecekler, aynı yapıyla:

| Panel | İçerik kartı |
|---|---|
| Öğretmen | Konular |
| Öğrenci | O haftanın konuları / bülten |
| Yönetici | Öğretmen listesi ya da paket tablosu |

Başlık bandı rengi her panelde farklı bir pastel olur. Liste kartı nane, seçili kart mavi olduğu için içerik kartı pembe ya da şeftali seçilir.

---

## 9. Ödevler paneli (yan panel / alttan kart)

- Başlık: "Ödevler · Elif Yıldız · 12 ödev". Altında **metin rozetleri**, ikon değil:
  - "6 öğrenciden": `#FFD6DE` / `#8C1F3B`
  - "3 öğretmenden": `#CFE1FF` / `#1B2A6B`
- Liste `batch_id` grupları olarak gelir. Her satırda başlık, tarih, dosya sayısı, yükleyen rozeti (ÖĞRENCİ / ÖĞRETMEN) ve aynı renkte 3px sol şerit bulunur.
- Şemada **durum, teslim tarihi ya da taslak alanı yok.** Bu alanlar gösterilmez.
- Alt buton: "Dosya yükle" (şeftali).

---

## 10. Mobil (390 × 844), 4a / 4b / 4c

- **Bar:** 50px yükseklik; beyaz logo ve renkli döşemeler. Döşemeler küçülür ama **adları kalır**. Bildirim, profil ve çıkış hamburger menüdedir.
- **4a, seçim yok:** liste 4 öğrenci gösterir, gerisi "Tümünü gör · 20" butonundadır. Altında kesikli bekleme alanı: `1.5px dashed rgba(36,55,166,.32)`, "Bir öğrenci seç".
- **4b, öğrenci seçili:** §7'deki kartın mobil hâli. Masaüstü kartı küçültülerek değil, **kendi ölçüleriyle** yapılır:
  - Kart: 18px yarıçap. Başlık bandı mavi `padding:10px 12px 10px 14px`, ad Sora 700 19px, saat 12.5px.
  - Butonlar: 👤 **44×44** ve Ödevler **44px** yükseklik.
  - Izgara ad satırının **altında**, krem gövdede: `grid-template-columns:36px repeat(4,1fr)`, `column-gap:8px`, `row-gap:5px`, `padding:10px 12px 8px`.
  - Ders kutusu **44px** yükseklik, 11px yarıçap, rakam 16px. Etiketler 10px, tarihler 11px.
- **4c, Ödevler açık:** alttan çıkan kart, ekranın üçte ikisi (563px). **Tek iş yapar: ödevler.** Aşağı sürükleyerek (>100px) ya da × ile kapanır.
- **Dokunma hedefleri:** en az 44px. **Metin:** en az 10px (etiket), gövde 12px ve üstü.

---

## 11. Kontrol listesi (her ekran için)

- [ ] Sol şerit yok, üstte yüzen bar var, döşemelerin adları yazılı
- [ ] Başlıklar Sora, liste adları Nunito, etiketler Plex Mono; Fredoka yok
- [ ] Pasteller tam tonda, kart gövdeleri krem
- [ ] `#8A93AC` hiçbir metinde yok
- [ ] Her metin ≥4.5:1 (katmanlar birleştirildikten sonra ölçülür)
- [ ] Seçili öğe tek kartta, tek satırda; paket 2×4 ızgara, çizgi yok
- [ ] Kutu rengi `status`'tan geliyor; kutu, tarih ve vurgu aynı kolonda
- [ ] Yan panel komşu kartı sıkıştırıyor, overlay değil; yeni sayfa açılmıyor
- [ ] Mobilde dokunma hedefleri ≥44px, yarısı kesilmiş satır yok
- [ ] `prefers-reduced-motion` açıkken animasyon yok
- [ ] Emoji yok
