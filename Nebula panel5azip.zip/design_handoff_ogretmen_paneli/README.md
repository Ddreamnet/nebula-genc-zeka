> **Güncel:** Tüm paneller için geçerli tasarım kuralları `PANEL-SISTEMI-5a.md` dosyasında. Onaylanan tasarım `panel-varyasyonlari.dc.html` içindeki `id="5a"` (masaüstü) ve `id="4a"/"4b"/"4c"` (mobil). Bu README'deki eski varyasyon notları (3a, 2a–2c) yalnızca geçmişi anlatıyor.

# Handoff: Öğretmen Paneli — 3a (yüzen bar + yan panel)

## Overview

Nebula Genç Zeka öğretmen panelinin yeniden tasarımı. Mevcut panel
(`web/src/components/dashboard/teacher-dashboard.tsx`) üstte logo + selamlama +
renkli buton dizisi, altta 320px öğrenci listesi + konu paneli, geri kalan her iş
ayrı diyalog pencerelerinde açılıyor. Bu tasarım aynı işlevleri korur ama:

- **Konular navigasyondan çıkar.** Öğrenciye tıklamak zaten konuları getiriyor;
  ayrı bir "Konular" sekmesi aynı yere giden ikinci bir kapı oluyordu.
- Geriye dört gerçek yer kalır (Öğrenciler, Program, Bakiye, Playground) —
  dört öğe için sol şerit fazla, o yüzden **yüzen üst bar**.
- **Ödevler** bir yer değil, seçili öğrencinin yanındaki bir eylem. Tıklanınca
  Konular kartını sıkıştıran bir **yan panel** açılır (üstünü kapatmaz).
- Şekil dili yumuşatılır: sitedeki 3px lacivert kontur + sert ofset gölge
  yerine 1px ince kontur + katmanlı yumuşak gölge.

## About the Design Files

Bu paketteki HTML dosyaları **tasarım referansıdır** — hedeflenen görünümü ve
davranışı gösteren prototipler, doğrudan kopyalanacak üretim kodu değil. Yapılacak
iş, bu tasarımları **projenin mevcut ortamında yeniden kurmak**: Next.js 15 +
React 19 + Tailwind v4, `web/src/components/panel-ui/*` bileşenleri ve
`web/src/app/globals.css` içindeki `.panel-theme` token'ları.

HTML'deki inline stiller prototip tekniğidir. Üretimde Tailwind sınıfları ve
mevcut `panel-ui` bileşenleri kullanılmalı; bu README'deki hex ve px değerleri
o sınıfların hangi değeri taşıması gerektiğini söyler.

## Fidelity

**High-fidelity.** Renkler, tipografi, boşluklar, yarıçaplar, gölgeler ve
hover durumları nihaidir. Kontrast WCAG AA'ya göre ölçüldü (metin 4.5:1,
başlık ölçeği 3:1) — panelde saatlerce çalışıldığı için bu bir alt sınır,
tercih değil.

Ölçüler 1180 × 742 px'lik bir çerçevede alınmıştır. Bu, panelin gerçek
viewport'u değil, prototipin sabit tuvalidir: üretimde dış ölçüler akışkan
olmalı (aşağıda "Responsive").

## Screens / Views

### Öğretmen paneli — ana ekran

**Purpose:** Öğretmen ders gününü buradan yürütür: sıradaki öğrenciyi görür,
konuları işaretler, ödev dosyalarını alıp verir.

**Layout** (dıştan içe):

```
frame  1180×742, radius 20, bg #E9EFFC, border 1px rgba(21,35,67,.14)
       shadow: 0 2px 4px rgba(21,35,67,.04), 0 22px 48px -24px rgba(21,35,67,.22)
│
├─ nav (birleşik L)  position:absolute; inset:18 22 22 22; z-index:5
│  │               pointer-events:none (içerik kümeleri auto)
│  │               ⟶ İKI KOL TEK PARÇA: ikisi de lacivert, birleşim görünmez
│  │
│  ├─ şerit       left:0 top:0 bottom:0; width:58; radius 17; overflow:hidden
│  │              bg #1B3564 (düz) + dekor SVG (viewBox 0 0 58 702, xMidYMid slice)
│  │              border 1px rgba(21,35,67,.22)
│  │              shadow: 0 2px 4px rgba(21,35,67,.06), 0 14px 32px -16px rgba(21,35,67,.32)
│  │
│  ├─ bar         left:0 right:0 top:0; height:58; radius 17
│  │              bg #1B3564 (düz); border 1px rgba(21,35,67,.22); aynı gölge
│  │
│  ├─ yama        left:1 top:30; 56×32; bg #1B3564
│  │              ⟶ barın alt konturunu ve sol alt yayını şeridin üzerinde gizler
│  │                 ÜÇÜ DE AYNI DÜZ RENK — dikis oluşamaz
│  │
│  ├─ sol küme    absolute left:15 top:0 height:58 — logo + selamlama
│  ├─ ikon şeridi absolute left:0 top:60 bottom:8 width:58
│  │              flex-direction:column; justify-content:center; gap:6
│  └─ sağ küme    absolute right:9 top:0 height:58 — dakika çipi, zil, çıkış, avatar
│
└─ content        position:absolute; inset:89 22 22 93
                  display:grid; grid-template-columns:195px 1fr; gap:16
                  ⟶ 93 = 22 (kenar) + 58 (şerit) + 13 (açıklık); 89 = 18 + 58 + 13.
                     Bu iki değer L nav'ın tüm anlamı — 22 verilirse içerik
                     şeridin altına girer.
   │
   ├─ öğrenci listesi kartı  (195px)
   │
   └─ ana kolon  display:flex; flex-direction:column; gap:13
      ├─ "şu an derste" şeridi
      └─ satır  flex:1; display:flex; gap:13; align-items:stretch
         ├─ Konular kartı   flex:1; min-width:0     → ölçülen 464px
         └─ Ödevler paneli  width:376px; flex-shrink:0
```

**Kritik nokta:** Ödevler paneli bir overlay DEĞİL. Konular kartıyla aynı flex
satırının iki çocuğudur; bu yüzden yükseklikleri yapısal olarak eşittir
(ayrı ayrı verilen değerler değil) ve panel kartı gerçekten sıkıştırır.
Overlay olarak kurulursa "yüksekliği onunla aynı olsun" şartı kaybolur.

---

### Bileşen: Barın içeriği

Bar lacivert; nav onun içinde değil, dikey şeritte. Barın içeriği iki mutlak
konumlu küme:

**Sol küme** — `position:absolute; left:15; top:0; height:58; display:flex; align-items:center; gap:13`
- Logo: **`logo-white.png`**, `height:40px; width:auto`. Yuvarlak/kare logo
  kullanılmaz; barda kelime logosu (wordmark) durur.
- Selamlama: "İyi dersler, Selin" — Fredoka 600, 13.5px, `#EAF1FF`.
  Genel bir karşılama değil, işin başında söylenen bir şey.
- Alt satır: "SALI, 6 EYLÜL · BUGÜN 3 DERS" — IBM Plex Mono, 9.5px,
  `rgba(207,225,255,.74)`

**"Konular" nav öğesi YOKTUR.** Konular seçili öğrencinin içeriğidir — sekme
olarak da, barın içinde de yer almaz.

**Sağ küme** — `position:absolute; right:9; top:0; height:58; display:flex; align-items:center; gap:8`
- Dakika bakiyesi çipi: `#C6F1DC` dolgu, `rgba(15,107,65,.26)` kontur,
  radius 11, padding 6px 11px. Sayı IBM Plex Mono 12.5px 600 `#0F6B41`,
  "DK" 9.5px 600 `#0E2B1D`.
- Bildirim zili: 34×34, `#FFD6DE`, kontur `rgba(255,214,222,.5)`, radius 11,
  ikon stroke `#8C1F3B`. Rozet: sağ üst -3/-3, min-width 16, height 16,
  radius 999, bg `#B22F4F`, 2px `#1B3564` kontur (şeklin dolgusu), sayı 9px 600
  `#FFFBF2`. — Bu **tek** bildirim göstergesidir; öğrenci satırlarında rozet yok.
- Çıkış: 34×34, dolgu `rgba(255,214,222,.10)`, kontur `rgba(255,214,222,.32)`,
  ikon `#FFD6DE`, hover dolgu `rgba(255,214,222,.22)`.
- Avatar: 34×34 daire, `#DCD2FF`, baş harfler Fredoka 600 13px `#2A1466`,
  `box-shadow:0 0 0 1px rgba(220,210,255,.4)`.
  Fotoğraf varsa onun yerine görüntülenir — yükleme yetkisi admin'de.

---

### Bileşen: Yüzen bar + şerit (birleşik L)

Navigasyon **tek parça bir L**: tam yükseklikte 58px şerit + tam genişlikte 58px
bar, aynı silüeti paylaşır. Birleşme yerine bir yama (56×26, barın dolgusunda)
konur; böylece barın alt konturu ve sol alt yayı şeridin üzerinde görünmez ve
ikisi tek şekil olarak okunur. SVG kontur yerine düz kutular kullanılır — SVG'de
yarıçaplar çerçeveyle birlikte bozulur.

**Şerit VE bar tek düz lacivert** — `#1B3564`, üçü de (şerit, bar, birleşim
yaması) aynı dolguyu taşır. Bu bilinçli: gradyan **olmadığı** için dikiş
oluşamaz. Daha önceki bir sürüm üç farklı gradyanı renk eşleştirerek
birleştirmeye çalıştı ve barın 4px altında sert bir basamak bıraktı — iki
gradyan yalnızca **bir** kenarda eşitlenebilir.

Tonal değişim şeridin dekor SVG'sinin içinde yaşar: `rnGlow` radial gradient,
(29, 470) merkezli 120×230 elips. Aşağıda merkezli ve y=60'tan önce sıfıra
düşer — barın devraldığı yer. Birleşimi görünmez tutan şey budur.

**İç köşeye tile konmaz.** Üzerine yatırılan bir kutuya `border-radius`
vermek yanlış tarafı keser (yay kutunun karşı köşesinde merkezlenir) ve
kavis yerine basamaklı bir çentik üretir; üstelik nav `z-index:5` olduğu için
öğrenci kartının yuvarlak köşesinin üzerine boyar. Tek dolguyla dik açılı
birleşim zaten tek parça okunur. Gerçek bir kavis isteniyorsa L **tek eleman**
olarak `clip-path`/SVG ile çizilmeli — kavis silüetin parçası olur, üzerine
konan bir kaplama değil.

Üzerine ana sayfadaki hero'nun dilinden dekor — yıldız kırıntıları, 4 kollu
parıltılar, dört gezegen (şeftali, turkuaz, halkalı mor, pembe; aynı radial
gradient tarifleri). Dekor SVG'si `preserveAspectRatio="xMidYMid slice"` ile
çizilir, `none` ile gezegenler elips olur. Dekor bilinçli olarak **ikon
bandının dışında** (y 250–450 boş bırakılır) — ikonların okunurluğu dekordan
önce gelir.

**Şerit ikonları** dikeyde ortalanır (`justify-content:center`), 44×44, sadece
ikon (`aria-label` + `title` zorunlu):
- Aktif: `#CFE1FF` dolgu, `#132750` mürekkep, kontur `rgba(207,225,255,.55)`,
  gölge `0 2px 6px -1px rgba(8,18,44,.45)`
- Boş: `rgba(207,225,255,.13)` dolgu, `#EAF1FF` mürekkep,
  kontur `rgba(207,225,255,.24)` — koyu ve dekorlu zeminde ikonun okunması için
  saydam yerine hafif dolgulu bir kutu şart
- Hover: her öğe kendi pasteline geçer (Program nane, Bakiye şeftali,
  Playground mor) ve mürekkep koyulaşır
- Kalem kalınlığı 1.9–2.0, boyut 20px (krem zeminde 1.7/19 idi — koyu zemin
  daha kalın kalem ister)
- Playground ikonu `gamepad-2` (sparkles değil)

**Bar da lacivert** — krem değil. İçindeki her şey açık mürekkebe döner:
logo **beyaz** versiyon (`logo-white.png`), selamlama `#EAF1FF`, alt satır
`rgba(207,225,255,.74)`, çıkış ikonu `#FFD6DE` (dolgu `rgba(255,214,222,.10)`),
zil rozetinin konturı `#1F3A69`. Dakika çipi (`#C6F1DC`) ve avatar (`#DCD2FF`)
pastel kalır — laciverte karşı zaten parıyor. Ölçülen kontrastlar: selamlama
9.09:1, alt satır 5.45:1, çıkış 8.53:1, çip mürekkebi 5.32:1.

(Not: bar bir **kardeş** katman olarak metnin arkasında durur, atası değil — bu
yüzden ata zincirini yürüyen kontrast denetçileri bu metinleri beyaz zemine
karşı ölçüp yanlış alarm verir. Üretimde barın dolgusunu metnin atası olan
kabın üzerine koymak bu tuzağı ortadan kaldırır.)

### Bileşen: Öğrenci listesi kartı (195px)

Gövde krem `#FFFBF2`, kontur `rgba(21,35,67,.13)`, radius 16,
shadow `0 1px 2px rgba(21,35,67,.045), 0 8px 20px -12px rgba(21,35,67,.12)`.

**Başlık bandı** — `#E8F4EC` (nane tint), alt kontur `rgba(15,107,65,.16)`,
padding 13/14/11:
- "Öğrencilerim" Fredoka 600 15px `#152343`
- Sayaç çipi: `#C6F1DC`, radius 999, padding 3px 8px, mono 10.5px 600 `#0F6B41`
- Arama alanı: bg `#FFFBF2`, kontur `rgba(15,107,65,.20)`, radius 11,
  padding `8px 11px 8px 31px`, ikon 15×15 `#5B6480` sol 10px.
  Focus: kontur `rgba(15,107,65,.48)` + `box-shadow:0 0 0 3px rgba(15,107,65,.12)`

**Bölüm etiketleri** — nokta + etiket + ince çizgi:
- "BUGÜN": nokta ve metin `#0F6B41`, çizgi `rgba(15,107,65,.20)`
- "BU HAFTA": nokta ve metin `#4A2FB8`, çizgi `rgba(74,47,184,.20)`
- mono 9.5px 600, `letter-spacing:.16em`, `white-space:nowrap`

**Satır** (`<button>`, tam genişlik, `text-align:left`):
```
padding 7px 9px  (derste olan satır 9px 9px)
border-left 3px solid <stripe>   → derste olan: #0F6B41, diğerleri transparent
radius 9, background <bg>        → derste olan: #E4F3EA, diğerleri transparent
hover: bugün bloğu #E8F4EC, hafta bloğu #EFEAFF
display:flex; align-items:center; gap:9
```
İçerik sırası: durum noktası (7×7 daire) → isim (flex:1, min-width:0,
13.5px 600 `#152343`, nowrap + ellipsis) → **okunmamış sayaç** → saat
(mono 10.5px, nowrap).

**Okunmamış ödev sayacı** — `min-width:16px; height:16px; padding:0 3.5px;
box-sizing:border-box; border-radius:999px`:
- Var: bg `#FFD6DE`, kontur 1.5px `#B22F4F`, sayı mono 9px 600 `#8C1F3B`, opacity 1
- Yok: hepsi transparent, `opacity:0` — düğüm kalır, böylece satırın
  kolon ritmi iki durumda da aynıdır (düğümü kaldırmak hizayı bozar).

Bu sayaç **teslim/bekliyor durumu değildir** — aşağıdaki "Veri modeli"ne bakın.

**Sıralama:** sonraki derse göre, "bugün" ve "bu hafta" olarak iki blok.
Öğretmenin günün ilk sorusu "sıradaki kim" — liste bunu cevaplar.

---

### Bileşen: "Şu an derste" şeridi

`#CFE1FF` dolgu, kontur `rgba(36,55,166,.24)`, radius 16, padding 14px 17px,
shadow `0 1px 2px rgba(36,55,166,.06), 0 8px 20px -12px rgba(36,55,166,.24)`.
`display:flex; align-items:center; gap:16; flex-wrap:wrap`

Sol blok (`flex:1; min-width:200px`):
- Rozet: "ŞU AN DERSTE", `#C6F1DC` dolgu, mono 9.5px 600 `.14em`, `#0F6B41`.
  İçindeki 5×5 nokta `nbNow` animasyonuyla nabız atar.
- İsim: Fredoka 600 17px `#152343`
- Saat aralığı: mono 11px 600 `#2437A6`
- İlerleme: 7px yüksek ray `rgba(21,35,67,.14)`, dolgu `#2437A6`,
  radius 999 + "24 dk kaldı" mono 10.5px 600 `#2437A6`

Sağ blok — iki buton:
- **Ödevler**: `#FFE1C4`, kontur `rgba(156,74,10,.34)`, metin `#3B1A05` 700.
  Panel açıkken `box-shadow:inset 0 1px 3px rgba(156,74,10,.20)` — basılı
  görünür, böylece paneli neyin açtığı okunur.
- **Ders işlendi**: `#C6F1DC`, kontur `rgba(15,107,65,.34)`, metin `#0E2B1D` 700,
  shadow `0 1px 2px rgba(15,107,65,.10)`, hover `0 5px 14px -4px rgba(15,107,65,.42)`

---

### Bileşen: Konular kartı (esner, ölçülen 464px)

Gövde krem, başlık bandı `#E9EFFC` (mavi tint), alt kontur `rgba(36,55,166,.16)`.
Başlıkta: "Konular" Fredoka 600 15px + altında "Elif Yıldız · 4. sınıf" 11px
`#5B6480` → ilerleme çubuğu (dolgu `#0F6B41`, ray `rgba(21,35,67,.12)`) + "2/6"
mono 10.5px 600 `#0F6B41` → 30×30 "+" düğmesi `#CFE1FF`.

**Konu satırı:**
```
padding 10px 11px, radius 12
border 1px solid <border>, border-left 3px solid <tone>
background <bg>, cursor:grab
hover: translateY(-1px) + shadow 0 4px 12px -6px rgba(21,35,67,.18)
```
Durum tonları:
| Durum | tone | dotBg | bg | border |
|---|---|---|---|---|
| Bitti | `#0F6B41` | `#C6F1DC` | `#FFFBF2` | `rgba(21,35,67,.10)` |
| Şu an | `#9C4A0A` | `#FFE1C4` | `#FDF4E9` | `rgba(156,74,10,.26)` |
| Sırada | `#5B6480` | `#E9EFFC` | `#FFFBF2` | `rgba(21,35,67,.10)` |

İşaret dairesi 20×20, 1.5px `tone` konturlu, içinde tik (bitti = `tone`,
diğerleri soluk). Başlık 13.5px 600, `min-width:0` + `nowrap` + `ellipsis`.

**Panel açıkken kaynak sayıları ("3 kaynak") ve durum rozetleri satırdan
kalkar** — sıkışan kartta yer yok, başlık okunurluğu daha değerli. Panel
kapalıyken bu bilgiler geri gelir (bkz. 2a varyasyonu).

---

### Bileşen: Ödevler yan paneli (376px)

Gövde krem, kontur `rgba(156,74,10,.26)`, radius 16,
shadow `0 2px 4px rgba(21,35,67,.05), 0 16px 38px -18px rgba(21,35,67,.32)`.

**Başlık bandı** — `#FBEFE1` (şeftali tint), alt kontur `rgba(156,74,10,.18)`:
- "Ödevler" Fredoka 600 17px + yanında "Elif Yıldız · 12 ödev" 12.5px `#5A2A05`
- Altında **ikon–sayı çiftleri** (sayaç kartı yok, satır içi):
  - Öğrenci: `#FFD6DE` dolgu, kontur `rgba(178,47,79,.26)`, radius 999,
    padding 3px 8px, ikon 12×12 `#8C1F3B`, sayı mono 10.5px 600 `#8C1F3B`
  - Öğretmen: `#CFE1FF` dolgu, kontur `rgba(36,55,166,.26)`,
    ikon 12×12 `#1B2A6B`, sayı `#1B2A6B`
- Kapat düğmesi 32×32, `#FFFBF2`, kontur `rgba(156,74,10,.24)`, hover `#FFE1C4`

**Ödev satırı** — iki katlı:
```
padding 10px 12px, radius 12
border 1px solid <border>, border-left 3px solid <stripe>
```
| Yükleyen | tone / stripe | chipBg | bg | border | rozet |
|---|---|---|---|---|---|
| Öğrenci | `#B22F4F` | `#FFD6DE` | `#FFF7F8` | `rgba(178,47,79,.24)` | ÖĞRENCİ |
| Öğretmen | `#2437A6` | `#CFE1FF` | `#F7FAFF` | `rgba(36,55,166,.22)` | ÖĞRETMEN |

Üst kat: başlık (13px 600, ellipsis) + yükleyen rozeti (mono 9px 600 `.08em`).
Alt kat: dosya sayısı çipi (krem, kontur `rgba(21,35,67,.12)`, radius 8,
mono 9.5px `#5B6480`, dosya ikonu 11×11) → esneyen boşluk → tarih (mono 9.5px).

Sol şerit rengi başlıktaki ikon–sayı çiftleriyle aynı — rozete bakmadan
kimin yüklediği anlaşılır.

**Alt bar:** tam genişlik "Dosya yükle" butonu, `#FFE1C4`,
kontur `rgba(156,74,10,.32)`, metin `#3B1A05` 700, yukarı ok ikonu.
("Yeni ödev ver" değil — öğretmen dosya yükler, bkz. veri modeli.)

## Interactions & Behavior

| Eylem | Sonuç |
|---|---|
| Program (şerit) | Sağdan bir yan panel kayarak girer ve **Konular kartı kalkar** — öğretmen haftalık ders programını tam genişlikte görür. Kapanınca Konular geri gelir. Geçiş: panel `transform:translateX(100%) → 0`, Konular `opacity 1 → 0` + `translateX(-8px)`, ikisi de `.26s cubic-bezier(.2,.7,.3,1)`; panel girişi Konular çıkışından ~60ms sonra başlar ki iki hareket birbirini ezmesin. |
| Öğretmen profil fotoğrafı | **Yükleme yetkisi admin'de** — öğretmen kendi fotoğrafını yükleyemez. Panelde sadece görüntülenir (barın sağındaki 34px avatar); fotoğraf yoksa baş harfler (`#DCD2FF` dolgu, `#4A2FB8` mürekkep) gösterilir. Admin tarafında yükleme/kırpma akışı ve `teachers.avatar_url` alanı gerekir. |
| Öğrenci satırına tıklama | Seçili öğrenci olur; Konular kartı ve şerit o öğrenciye döner. Ayrı bir "Konular" navigasyonu yok. |
| "Ödevler" butonu | Sağdan yan panel açılır, Konular kartı 464px'e sıkışır (masaüstü). Buton basılı duruma geçer. |
| Bakiye (nav) | Aynı yan panel mekanizması, bakiye içeriğiyle. |
| Panel kapat (×) | Panel kapanır, Konular kartı tam genişliğe döner, kaynak sayıları geri gelir. |
| "Ders işlendi" | Dersi işlenmiş işaretler, dakika bakiyesinden düşer. |
| Konu satırı sürükleme | Sıralama (`cursor:grab`; mevcut kodda `@dnd-kit` var). |
| Zil | Okunmamış öğrenci yüklemeleri listesi. |

**Mobil:** yan panel yerine diyalog. Kullanıcı sayfa açılmasını istemiyor —
mobilde tam ekran diyalog, masaüstünde sıkıştıran panel.

**Geçişler** — hepsi kısa ve tek dilde:
- Buton/kart hover: `transform .18s cubic-bezier(.2,.7,.3,1)` + `box-shadow .18s`,
  `translateY(-1px)`
- Liste satırı hover: `background .16s cubic-bezier(.2,.7,.3,1)`
- Input focus: `border-color .18s, box-shadow .18s`
- Nabız: `@keyframes nbNow { 0%,100% { box-shadow:0 0 0 0 rgba(15,107,65,.42) }
  50% { box-shadow:0 0 0 5px rgba(15,107,65,0) } }`, `2.4s ease-in-out infinite`

`prefers-reduced-motion` altında nabız ve translateY kapatılmalı.

## State Management

```
selectedStudentId   → Konular kartı, şerit, Ödevler paneli bunu izler
drawer              → null | 'homework' | 'balance'  (aynı yan panel yuvası)
studentQuery        → arama alanı
unreadByStudent     → Record<studentId, number>  (satır sayacı + zil rozeti)
activeLesson        → { studentId, startsAt, endsAt } → "24 dk kaldı" bundan türetilir
topicsByStudent     → sıra + durum (drag-and-drop sonrası yazılır)
batchesByStudent    → homework_submissions, batch_id ile gruplu
```

"24 dk kaldı" ve ilerleme yüzdesi **saatten türetilmeli**, ayrı alan olarak
tutulmamalı — yoksa iki kaynak birbirinden ayrı düşer.

## Veri modeli — ödevler (dikkat)

`homework_submissions` satırları `batch_id` ile gruplanır ve
`title`, `description`, `file_url`, `file_name`, `uploaded_by_user_id` taşır.
**Şemada durum (status), teslim tarihi (due_date) ve taslak alanı YOK.**
Kaynak: `upload-homework-dialog.tsx`, `homework-list-dialog.tsx`.

Bu yüzden bir satır "teslim edildi / bekliyor" diyemez. Tek durum
`uploaded_by_user_id`: dosyayı öğrenci mi öğretmen mi yükledi. Mevcut kod bunu
sol kenar rengi + "Öğrenci"/"Öğretmen" etiketiyle gösterir; tasarım aynı ayrımı
korur.

Satırdaki sayaç bu yüzden **okunmamış öğrenci yüklemesi** sayar —
`homework-notification-bell.tsx`'in gerçekten bildirdiği şey
("Bir öğrenciniz yeni ödev yükledi").


## Ders modeli ve tamamlama akışı (KRİTİK)

Kaynak: `web/src/lib/lesson/types.ts`, `web/src/lib/lesson/service.ts`.

`lesson_instances` tablosunda **her 40 dakikalık ders ayrı bir satırdır**:
`lesson_number`, `lesson_date`, `start_time`, `end_time`,
`status: 'planned' | 'completed'`, `rescheduled_count`, `original_date`,
`package_cycle`. Dersler haftada bir gün 40+40 olarak işlenir, yani **aynı
günde iki satır** vardır (1-2, 3-4, 5-6, 7-8).

Bu yüzden tek bir "Ders işlendi" butonu yanlıştır: hangi satırı tamamladığını
söyleyemez. Kullanılacak RPC'ler:

| Eylem | Fonksiyon |
|---|---|
| Dersi tamamla | `rpc_complete_lesson(p_instance_id)` |
| Geri al | `rpc_undo_complete_lesson(p_instance_id)` |
| Kalan hak | `getRemainingRights(studentId, teacherId)` → total / completed / remaining / cycle |
| Sıradaki ders | `getNextCompletableInstance(...)` |

### Ders zinciri

Her ders kendi satırıdır: işaret dairesi · "7. ders" · gün · saat aralığı ·
durum rozeti · ertele ikonu. Aynı günün iki dersi, **kartlar arasındaki iki
yarım halka** ile bağlanır — solda ve sağda, kart kenarından 14px içeride,
7×14px, `border-radius:999px 0 0 999px` (sol) / `0 999px 999px 0` (sağ).

Geometri veriden türetilir, elle yerleştirilmez:

```
link = 'linked' → gap 14px, halka 14px, renk #8A93AC
link = 'broken' → gap 26px, halka  9px, renk #B22F4F + aralarında kırık işareti
link = 'none'   → gap 20px, halka opacity 0   (sonraki satır ilgisiz bir çift)
ringBottom = (gap - ringH) / 2
```

Bu şart: aksi hâlde kopuk bir çiftte halkalar boşluğu ıskalar. Kopukluk bir
etiketle değil, **şeklin kendisiyle** anlatılır.

Durum tonları:

| Durum | bg | kontur | ton | halka | rozet |
|---|---|---|---|---|---|
| İşlendi | `#E4F3EA` | `rgba(15,107,65,.28)` | `#0F6B41` | `#C6F1DC` | İŞLENDİ |
| Şu an | `#FDF4E9` | `rgba(156,74,10,.30)` | `#9C4A0A` | `#FFE1C4` | ŞU AN |
| Planlı | `#FFFBF2` | `rgba(21,35,67,.12)` | `#5B6480` | `#F2F5FC` | PLANLI |
| Ertelendi | `#FFF7F8` | `rgba(178,47,79,.26)` | `#B22F4F` | `#FFD6DE` | ERTELENDİ |

**Geri alma:** işaretli derse tekrar dokunmak (`rpc_undo_complete_lesson`).
Ayrı bir "geri al" düğmesi yok.

**Erteleme:** her satırın sağındaki 26×26 takvim ikonu. Öğretmen yeni tarihi
seçer; `lesson_date` güncellenir, `rescheduled_count` artar, `original_date`
korunur. Ertelenen ders "9 Eylül'den ertelendi" gibi bir alt not taşır ve
çiftinin zinciri kopuk çizilir.

**Kapsam:** masaüstünde seçili **günün çifti** görünür, haftanın tamamı
"Bu haftanın tümü · 4 ders" açacağının ardındadır. Dört satır + boşlukları
şeridi 314px'e çıkarıp altındaki satırı aç bırakıyordu; ölçüldü. Mobil zaten
günün çiftini gösterir.

## Geçişler ve animasyon

Tümü `cubic-bezier(.2,.7,.3,1)`; `prefers-reduced-motion` altında hepsi kapanır.

| Nerede | Ne | Süre |
|---|---|---|
| Yan panel (masaüstü) | `transform:translateX(100%) → 0` | .26s |
| Konular kartı | panel açılırken `464px`'e sıkışır | .26s, aynı eğri |
| Program → yan panel | panel girer, **Konular kartı kalkar**: `opacity 1 → 0` + `translateX(-8px)`; panelin girişi Konular'ın çıkışından **~60ms sonra** başlar ki iki hareket birbirini ezmesin | .26s |
| Alttan çıkan kart (mobil) | `transform:translateY(100%) → 0` + arka plan perdesi `opacity 0 → 1` | .28s / .2s |
| Kart kapanma | aşağı sürükleme veya × ; 100px'i geçen sürükleme kapatır | .22s |
| Arama alanı | ikondan alana: `width 30px → %100`, `text-indent` sıfırlanır | .26s |
| Buton hover | `translateY(-1px)` + gölge | .18s |
| Liste satırı hover | yalnızca `background` | .16s |
| Ders satırı tamamlama | işaret dairesi doluya geçer, satır `#FFFBF2 → #E4F3EA` | .18s |
| "Şu an derste" nabzı | `@keyframes nbNow` — `box-shadow 0 0 0 0 → 0 0 0 5px` şeffafa | 2.4s sonsuz |

**Yan panel ≠ overlay.** Konular kartıyla aynı flex satırının iki çocuğudur;
yükseklikleri bu yüzden yapısal olarak eşittir. Overlay yapılırsa "aynı
yükseklik" şartı kaybolur.

## Öğretmen profil fotoğrafı

**Yükleme yetkisi admin'dedir.** Öğretmen kendi fotoğrafını yükleyemez; panelde
yalnızca görüntülenir (barın sağındaki 34px avatar). Fotoğraf yoksa baş harfler
gösterilir (`#DCD2FF` dolgu, `#2A1466` mürekkep). Gereken: `teachers.avatar_url`
alanı ve admin panelinde yükleme/kırpma akışı.

## Mobil uygulama (4a / 4b / 4c)

390 × 844. Aynı mantık, üç durum:

- **4a — seçim yok.** Liste yalnızca **4 öğrenci** gösterir, gerisi "Tümünü gör ·
  20" düğmesinin ardındadır. Altta kesikli çerçeveli bir alan seçim bekler
  (`1.5px dashed rgba(36,55,166,.32)`, "Bir öğrenci seç"). Dolu bir kart değil,
  bilinçli olarak boş bir yuva.
- **4b — öğrenci seçili.** O alan seçili öğrencinin kartı (ad soyad sola dayalı,
  gün/saat, kalan hak) + günün ders zinciri + Konular ile dolar.
- **4c — ödevler açık.** Alttan çıkan kart, üçte iki yükseklik (563px).
  **Tek iş yapar: ödevler.** Program, Bakiye ve Konular'ın kendi girişleri
  vardır; hepsini sunan bir kart, bara rakip ikinci bir navigasyon olurdu.

**Bar mobilde:** dikeyde 50px'e iner — solda beyaz logo, sağda dört nav ikonu
ve hamburger. Bildirim, profil ve çıkış hamburgerin içindedir; rozet oraya taşınır.

**"Şu an derste" şeridi mobilde tek satır:** ilerleme çubuğu ayrı bir satır
olmak yerine şeridin kendi zeminine döner
(`linear-gradient(90deg, #A9C8FF 0 60%, #CFE1FF 60% 100%)`).

**Derste olmayan öğrenci** (4b/4c'de Kerem Aslan): nabız atan yeşil rozet yerine
sade `SALI 18:00` rozeti, sola dayalı ad soyad ve altında gün/saat.

## Ödev paneli — yükleyen dökümü

Rozetler ikon değil **metin**: "6 öğrenciden" (`#FFD6DE` / `#8C1F3B`) ve
"3 öğretmenden" (`#CFE1FF` / `#1B2A6B`), başlıktaki toplam sayının hemen
yanında. Sayıların toplamı başlıktaki sayıya eşit olmalıdır.

Panelin gövdesi `overflow-y:auto` — 12 ödev sabit bir kutuya sığmaz.

## Design Tokens

Bu değerler `web/src/app/globals.css` içindeki `.panel-theme` bloğuyla
hizalıdır; yeni token uydurmayın, oradaki adları kullanın.

**Pastel dolgular** — `#C6F1DC` nane · `#FFE1C4` şeftali · `#FFD6DE` pembe ·
`#CFE1FF` mavi · `#DCD2FF` mor

**Tint bantlar** (kart başlıkları) — `#E8F4EC` nane · `#FBEFE1` şeftali ·
`#E9EFFC` mavi · `#EFEAFF` mor · `#E4F3EA` seçili satır · `#FDF4E9` aktif konu ·
`#FFF7F8` öğrenci ödevi · `#F7FAFF` öğretmen ödevi

**Yüzeyler** — `#FFFBF2` kart · `#E9EFFC` çalışma zemini · `#1B3564` uzay mavisi
(şerit; 3a'da kullanılmıyor, 2a/2c'de var)

**Mürekkepler** — ölçülmüş kontrastlarla:
| Hex | Kullanım | Kontrast |
|---|---|---|
| `#152343` | birincil metin | 13.9:1 krem üstünde |
| `#2C3550` | ikincil metin (koyu zemin) | 9.8:1 |
| `#5B6480` | üçüncül metin | 5.68:1 krem, 4.81:1 tint |
| `#0F6B41` | nane vurgu | 5.32:1 `#C6F1DC` üstünde |
| `#9C4A0A` | şeftali vurgu | 4.95:1 `#FFE1C4` üstünde |
| `#B22F4F` / `#8C1F3B` | pembe vurgu / pembe üstü mürekkep | 5.1:1 |
| `#2437A6` / `#1B2A6B` | mavi vurgu / mavi üstü mürekkep | 6.4:1 |
| `#4A2FB8` | mor vurgu | 6.9:1 krem üstünde |
| `#0E2B1D` | nane üstü koyu mürekkep | 11.2:1 |
| `#3B1A05` / `#5A2A05` | şeftali üstü koyu mürekkep | 10.4:1 / 7.1:1 |

**`#8A93AC` metin olarak kullanılmaz.** `globals.css`'te `--color-outline`,
yani bir kontur token'ı; metin için `--color-on-surface-variant` (`#5B6480`).

**Tipografi**
| Rol | Font | Boyut / ağırlık |
|---|---|---|
| Kart başlığı | Fredoka 600 | 15–17px, `letter-spacing:-.02em` |
| Gövde / isim | Nunito 600 | 13–13.5px |
| İkincil satır | Nunito 400 | 11–12.5px |
| Etiket / rozet | IBM Plex Mono 600 | 9–10.5px, `letter-spacing:.14–.16em`, UPPERCASE |
| Sayı | IBM Plex Mono 600 | 9–13px |

**Yarıçaplar** — 8 (küçük çip) · 9 (liste satırı) · 10–11 (ikon düğme, input) ·
12 (buton, konu satırı) · 16 (kart) · 17 (yüzen bar) · 20 (çerçeve) · 999 (pill)

**Gölgeler** — hepsi iki katmanlı: yakın ve sert olmayan bir temas gölgesi +
geniş, düşük opaklıklı bir yayılım. Sitedeki `0 Npx 0 0` sert ofset gölge
panelde kullanılmaz.
```
kart:       0 1px 2px rgba(21,35,67,.045), 0 8px 20px -12px rgba(21,35,67,.12)
yüzen bar:  0 2px 4px rgba(21,35,67,.04),  0 14px 32px -16px rgba(21,35,67,.26)
yan panel:  0 2px 4px rgba(21,35,67,.05),  0 16px 38px -18px rgba(21,35,67,.32)
buton:      0 1px 2px <tone .10>  → hover 0 4–6px 12–16px -4px <tone .34–.42>
```

**Boşluk** — 1 · 3 · 5 · 7 · 8 · 9 · 10 · 13 · 16 · 22 px. Kartlar arası 13–16,
çerçeve içi 22, kart içi 9–18.

## Assets

- `web/public/landing/logo-white.png` — lacivert barın üzerindeki kelime logosu,
  `height:40px`. Pakete kopyalandı. (`logo-black.png` de pakette; açık zeminli
  varyasyonlar 2a–2c onu kullanır.)
- Yuvarlak/kare logo (`web/public/brand/nebula-square.png`) 3a'da
  **kullanılmaz** — sadece 2a/2c'deki ikon şeridi varyasyonlarında.
- İkonlar: `lucide-react` — Users, Calendar, Wallet, Sparkles, Bell, LogOut,
  Search, FileText, Check, Plus, X, Upload, User, GraduationCap.
  Prototipte lucide'ın gerçek path verisi elle çizilidir; üretimde
  `lucide-react` bileşenlerini kullanın. Kalem kalınlığı bilinçli olarak
  **1.7–1.9** (lucide varsayılanı 2) — daha ince, daha yumuşak.

## Responsive

Prototip 1180×742 sabit tuvalde. Üretimde:
- Öğrenci listesi 195px sabit, ana kolon esner.
- < ~1100px: yan panel sıkıştırmak yerine overlay olur (Konular kartına
  minimum genişlik bırakılamıyorsa).
- < 768px: öğrenci listesi tam genişlik, seçim sonrası Konular'a geçiş;
  yan panel yerine tam ekran diyalog.
- Yüzen barın 3 kolonlu grid'i daralınca nav ikon-only'ye düşebilir; logo
  ve avatar kalır.

## Files

| Dosya | İçerik |
|---|---|
| `panel-varyasyonlari.dc.html` | Tüm varyasyonlar. **Onaylananlar: `id="3a"` (masaüstü) ve `id="4a"/"4b"/"4c"` (mobil)** — dosyanın en üstündeki iki bölüm. 2a/2b/2c aşağıda, karşılaştırma için. |
| `logo-black.png` | Yüzen bardaki logo |
| `github.md` | Repo/branch kaydı ve ekran ↔ kaynak dosya eşlemesi |

3a ve 4a–4c dışındaki varyasyonlar referans olarak bırakıldı: **2a** ikon şeridi, **2b** yüzen bar (renksiz ilk hâl), **2c** ikon şeridi + yan panel.

## Mevcut koddan değişenler

- Selamlamadaki emoji kaldırıldı (marka rehberi emoji kullanmıyor);
  yerine tarih + gün içindeki ders sayısı.
- Sert ofset gölgeler ve 3px konturlar panelde kullanılmıyor.
- Pastel dolgu kart gövdelerinden başlık bantlarına taşındı — uzun süre
  bakılan yüzey krem kalır.
- "Konular" navigasyondan çıktı; ödev diyaloğu yan panele döndü.
